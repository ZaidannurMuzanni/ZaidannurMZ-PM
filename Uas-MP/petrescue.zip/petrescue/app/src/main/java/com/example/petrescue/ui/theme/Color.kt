package com.example.petrescue.ui.theme

import androidx.compose.ui.graphics.Color

// --- WARNA EXISTING ---
val RescueOrange = Color(0xFFFF6F00)
val RescueOrangeDark = Color(0xFFC43E00)
val RescueBlue = Color(0xFF263238)
val RescueBg = Color(0xFFFFF3E0)

// --- WARNA BARU UNTUK SPLASH SCREEN ---
val RescueGreen = Color(0xFF2ED573) // Hijau cerah neon
val RescueDarkBg = Color(0xFF1C2429) // Latar belakang gelap keabu-abuan

// Mapping ke Material Theme (Tetap sama)
val Purple80 = RescueOrange
val PurpleGrey80 = RescueBlue
val Pink80 = RescueOrangeDark

val Purple40 = RescueOrange
val PurpleGrey40 = RescueBlue
val Pink40 = RescueOrangeDark