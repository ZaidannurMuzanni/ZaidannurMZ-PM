package com.example.petrescue.data.remote

import android.content.Context
import io.appwrite.Client
import io.appwrite.services.Account
import io.appwrite.services.Databases
import io.appwrite.services.Storage

object AppwriteClient {
    private const val ENDPOINT = "https://nyc.cloud.appwrite.io/v1" // Ganti jika self-hosted
    private const val PROJECT_ID = "696384340004a84c832d"

    lateinit var client: Client
    lateinit var account: Account
    lateinit var databases: Databases
    lateinit var storage: Storage

    // Panggil ini sekali di MainActivity atau Application class
    fun init(context: Context) {
        client = Client(context)
            .setEndpoint(ENDPOINT)
            .setProject(PROJECT_ID)
            .setSelfSigned(true) // Hapus jika production

        account = Account(client)
        databases = Databases(client)
        storage = Storage(client)
    }
}