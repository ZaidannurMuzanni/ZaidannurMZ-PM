package com.example.petrescue.ui.screens.onboarding

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.petrescue.ui.theme.RescueBlue
import com.example.petrescue.ui.theme.RescueGreen
import kotlinx.coroutines.launch

data class OnboardingPage(
    val title: String,
    val description: String,
    val icon: ImageVector
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(
    onNavigateToRegister: () -> Unit,
    onNavigateToLogin: () -> Unit
) {
    val pages = listOf(
        OnboardingPage(
            "Together We Save Them",
            "PetRescue membantu melaporkan dan menyelamatkan hewan terdampak bencana secara cepat.",
            Icons.Default.Pets
        ),
        OnboardingPage(
            "Quick Report & Action",
            "Ambil foto, kirim lokasi, dan biarkan relawan di sekitar segera bertindak.",
            Icons.Default.LocationOn
        ),
        OnboardingPage(
            "Real-time Updates",
            "Pantau proses evakuasi dan pastikan hewan kesayangan aman di shelter.",
            Icons.Default.HealthAndSafety
        )
    )

    val pagerState = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FA))
            .padding(24.dp)
    ) {
        // --- HEADER ---
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PetRescue",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = RescueBlue,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center
            )

            // Tombol Skip hanya muncul jika BUKAN halaman terakhir
            if (pagerState.currentPage < pages.size - 1) {
                TextButton(
                    onClick = onNavigateToLogin,
                    modifier = Modifier.absoluteOffset(x = 16.dp)
                ) {
                    Text("Skip", color = RescueGreen, fontWeight = FontWeight.Bold)
                }
            } else {
                // Placeholder biar layout header tidak goyang saat tombol skip hilang
                Spacer(modifier = Modifier.width(60.dp))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // --- SLIDER ---
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f)
        ) { position ->
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // KOTAK GAMBAR
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        imageVector = pages[position].icon,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(0.5f),
                        colorFilter = ColorFilter.tint(RescueGreen)
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, RescueGreen.copy(alpha = 0.1f)),
                                    startY = 300f
                                )
                            )
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))

                // JUDUL
                Text(
                    text = pages[position].title,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 28.sp,
                        lineHeight = 36.sp
                    ),
                    textAlign = TextAlign.Center,
                    color = RescueBlue
                )

                Spacer(modifier = Modifier.height(16.dp))

                // DESKRIPSI
                Text(
                    text = pages[position].description,
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                    color = Color.Gray,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        // --- DOTS ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 24.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(pages.size) { iteration ->
                val color = if (pagerState.currentPage == iteration) RescueGreen else Color(0xFFE0E0E0)
                val width = if (pagerState.currentPage == iteration) 24.dp else 8.dp

                Box(
                    modifier = Modifier
                        .padding(4.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(color)
                        .size(width = width, height = 8.dp)
                )
            }
        }

        // --- BAGIAN TOMBOL (LOGIC BARU) ---
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Cek: Apakah ini halaman terakhir? (Halaman ke-3, index 2)
            if (pagerState.currentPage == pages.size - 1) {

                // --- JIKA HALAMAN TERAKHIR: TAMPILKAN TOMBOL AKSI ---

                // 1. Tombol Register
                Button(
                    onClick = onNavigateToRegister,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RescueGreen),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "Get Started",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.Black
                    )
                }

                // 2. Tombol Login
                OutlinedButton(
                    onClick = onNavigateToLogin,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RescueBlue),
                    border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "I have an account",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

            } else {

                // --- JIKA BELUM HALAMAN TERAKHIR: TAMPILKAN TOMBOL NEXT ---

                Button(
                    onClick = {
                        // Geser ke halaman berikutnya
                        scope.launch {
                            pagerState.animateScrollToPage(pagerState.currentPage + 1)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = RescueBlue), // Pakai warna biru/hitam biar beda
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "Next",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                // Spacer agar tinggi layout tetap konsisten (opsional, biar tombol Next posisinya sama dengan Get Started)
                Spacer(modifier = Modifier.height(56.dp))
            }
        }
    }
}