package com.example.petrescue.ui.screens.rescue

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.petrescue.ui.navigation.Screen
import com.example.petrescue.ui.theme.RescueGreen
import com.example.petrescue.ui.theme.RescueOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EvacuationListScreen(
    // Kita butuh NavController untuk pindah ke RescueUpdateScreen
    // Jika di AppNavigation.kt pakai composable{ EvacuationListScreen() }, pastikan pass navController
    // Tapi untuk sementara saya buat parameter callback biar aman:
    onNavigateToUpdate: (String) -> Unit = {}
) {
    val viewModel: EvacuationViewModel = viewModel()

    // Refresh data setiap kali layar dibuka
    LaunchedEffect(Unit) {
        viewModel.fetchEvacuations()
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Evacuation List", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { /* Notifikasi */ }) {
                        Icon(Icons.Default.Notifications, contentDescription = null)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color(0xFFF9F9F9))
            )
        },
        containerColor = Color(0xFFF9F9F9)
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 20.dp)
                .fillMaxSize()
        ) {
            // 1. SEARCH BAR
            SearchBar(
                query = viewModel.searchQuery,
                onQueryChange = viewModel::onSearchQueryChange
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 2. FILTER CHIPS
            FilterRow(
                selectedFilter = viewModel.selectedFilter,
                onFilterSelect = viewModel::onFilterSelected
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 3. LIST OF CARDS
            if (viewModel.isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = RescueGreen)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(bottom = 80.dp) // Jarak bawah agar tidak tertutup navbar
                ) {
                    items(viewModel.filteredReports) { item ->
                        EvacuationCard(
                            item = item,
                            onClick = { onNavigateToUpdate(item.id) }
                        )
                    }
                }
            }
        }
    }
}

// --- COMPONENTS ---

@Composable
fun SearchBar(query: String, onQueryChange: (String) -> Unit) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFEFEFEF), // Abu muda banget
        modifier = Modifier.fillMaxWidth().height(50.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp)
        ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray)
            Spacer(modifier = Modifier.width(12.dp))
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                textStyle = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
                decorationBox = { innerTextField ->
                    if (query.isEmpty()) {
                        Text("Search by pet ID or location...", color = Color.Gray)
                    }
                    innerTextField()
                }
            )
        }
    }
}

@Composable
fun FilterRow(selectedFilter: String, onFilterSelect: (String) -> Unit) {
    val filters = listOf("All", "Waiting", "In Progress", "Safe")

    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(filters) { filter ->
            val isSelected = selectedFilter == filter
            val bgColor = if (isSelected) RescueGreen else Color(0xFFEFEFEF)
            val textColor = if (isSelected) Color.White else Color.Gray

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = bgColor,
                modifier = Modifier.clickable { onFilterSelect(filter) }
            ) {
                Text(
                    text = filter,
                    color = textColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
fun EvacuationCard(item: EvacuationItem, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // FOTO HEWAN (Bulat)
            if (item.imageId.isNotEmpty()) {
                val imageUrl = "https://nyc.cloud.appwrite.io/v1/storage/buckets/6963890d002b17d6566e/files/${item.imageId}/view?project=696384340004a84c832d"
                AsyncImage(
                    model = imageUrl,
                    contentDescription = null,
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color.LightGray),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color.Gray),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Pets, contentDescription = null, tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            // INFO TENGAH
            Column(modifier = Modifier.weight(1f)) {
                // Nama & ID
                Text(
                    text = "${item.title} (ID: ${item.id.takeLast(3)})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Lokasi
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = Color.Gray, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(item.locationName, color = Color.Gray, fontSize = 12.sp, maxLines = 1)
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Volunteer
                Text(
                    text = "VOLUNTEER",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.LightGray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
                Text(
                    text = item.volunteerName,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.DarkGray,
                    fontWeight = FontWeight.Bold
                )
            }

            // INFO KANAN (Status Badge)
            Column(horizontalAlignment = Alignment.End) {
                // Warna Badge
                val (badgeBg, badgeText, badgeLabel) = when(item.status) {
                    "in_progress" -> Triple(Color(0xFFE3F2FD), Color(0xFF2196F3), "IN EVACUATION") // Biru
                    "rescued" -> Triple(Color(0xFFE8F5E9), RescueGreen, "SAFE") // Hijau
                    else -> Triple(Color(0xFFFFF3E0), RescueOrange, "WAITING") // Orange
                }

                Surface(
                    color = badgeBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = badgeLabel,
                        color = badgeText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Text(item.timeAgo, color = Color.LightGray, fontSize = 12.sp)
            }
        }
    }
}