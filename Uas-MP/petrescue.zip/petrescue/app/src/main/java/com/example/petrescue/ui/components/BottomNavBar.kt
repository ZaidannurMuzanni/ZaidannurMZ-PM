package com.example.petrescue.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.petrescue.ui.navigation.Screen
import com.example.petrescue.ui.theme.RescueGreen
import com.example.petrescue.ui.theme.RescueOrange

// Data Class untuk Item Menu
data class BottomNavItem(
    val name: String,
    val route: String,
    val icon: ImageVector
)

@Composable
fun BottomNavBar(navController: NavController) {
    val items = listOf(
        BottomNavItem("Home", Screen.Home.route, Icons.Default.Home),
        BottomNavItem("Maps", Screen.Maps.route, Icons.Default.Map),
        // Kita ganti icon jadi 'Add' biasa karena akan dibungkus lingkaran
        BottomNavItem("Lapor", Screen.CreateReport.route, Icons.Default.Add),
        BottomNavItem("Evakuasi", Screen.EvacuationList.route, Icons.Default.HealthAndSafety),
        BottomNavItem("Profil", Screen.Profile.route, Icons.Default.Person)
    )

    val navBackStackEntry = navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry.value?.destination?.route

    NavigationBar(
        containerColor = Color.White, // Ganti background putih bersih
        tonalElevation = 10.dp
    ) {
        items.forEach { item ->
            val isSelected = currentRoute == item.route
            val isLapor = item.name == "Lapor"

            NavigationBarItem(
                icon = {
                    if (isLapor) {
                        // --- CUSTOM ICON UNTUK TOMBOL LAPOR (BESAR) ---
                        Surface(
                            color = RescueOrange, // Warna Background Tombol
                            shape = CircleShape,
                            shadowElevation = 6.dp, // Efek bayangan biar pop-up
                            modifier = Modifier.size(52.dp) // Ukuran Tombol Besar
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.fillMaxSize()
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.name,
                                    tint = Color.White, // Icon warna putih
                                    modifier = Modifier.size(32.dp) // Ukuran Icon di dalam lingkaran
                                )
                            }
                        }
                    } else {
                        // --- ICON BIASA ---
                        Icon(
                            imageVector = item.icon,
                            contentDescription = item.name,
                            modifier = Modifier.size(24.dp),
                            tint = if (isSelected) RescueGreen else Color.Gray
                        )
                    }
                },
                label = {
                    // Sembunyikan label untuk tombol Lapor agar tidak berantakan
                    if (!isLapor) {
                        Text(
                            text = item.name,
                            color = if (isSelected) RescueGreen else Color.Gray,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                selected = isSelected,
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(Screen.Home.route) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                // Hapus indikator standar Material 3 untuk tombol Lapor agar lingkaran kita terlihat penuh
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = if (isLapor) Color.Transparent else MaterialTheme.colorScheme.secondaryContainer
                )
            )
        }
    }
}