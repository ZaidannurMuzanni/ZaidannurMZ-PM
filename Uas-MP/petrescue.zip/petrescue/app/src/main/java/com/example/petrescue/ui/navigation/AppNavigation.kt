package com.example.petrescue.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.petrescue.ui.components.BottomNavBar
import com.example.petrescue.ui.screens.detail.DetailScreen
import com.example.petrescue.ui.screens.home.HomeScreen
import com.example.petrescue.ui.screens.login.LoginScreen
import com.example.petrescue.ui.screens.maps.MapsScreen
import com.example.petrescue.ui.screens.onboarding.OnboardingScreen
import com.example.petrescue.ui.screens.profile.ProfileScreen
import com.example.petrescue.ui.screens.register.RegisterScreen
import com.example.petrescue.ui.screens.report.CreateReportScreen
import com.example.petrescue.ui.screens.rescue.EvacuationListScreen
import com.example.petrescue.ui.screens.rescue.RescueUpdateScreen
import com.example.petrescue.ui.screens.splash.SplashScreen

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    // Cek halaman saat ini untuk Menampilkan/Menyembunyikan BottomBar
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Daftar layar yang TIDAK boleh ada Bottom Bar
    val noBottomBarRoutes = listOf(
        Screen.Splash.route,
        Screen.Onboarding.route,
        Screen.Login.route,
        Screen.Register.route,
        Screen.CreateReport.route, // Biasanya form lapor full screen
        Screen.DetailReport.route,
        Screen.RescueUpdate.route
    )

    val showBottomBar = currentRoute !in noBottomBarRoutes

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                BottomNavBar(navController = navController)
            }
        }
    ) { innerPadding ->

        NavHost(
            navController = navController,
            startDestination = Screen.Splash.route,
            modifier = Modifier.padding(innerPadding) // Wajib agar konten tidak tertutup navbar
        ) {
            // 1. Splash
            composable(Screen.Splash.route) {
                SplashScreen(
                    onNavigateToHome = {
                        navController.navigate(Screen.Home.route) { popUpTo(0) }
                    },
                    onNavigateToLogin = {
                        navController.navigate(Screen.Onboarding.route) { popUpTo(0) }
                    }
                )
            }

            // 2. Onboarding
            composable(Screen.Onboarding.route) {
                OnboardingScreen(
                    onNavigateToRegister = { navController.navigate(Screen.Register.route) },
                    onNavigateToLogin = { navController.navigate(Screen.Login.route) }
                )
            }

            // 3. Login
            composable(Screen.Login.route) {
                LoginScreen(
                    onLoginSuccess = {
                        navController.navigate(Screen.Home.route) { popUpTo(0) }
                    },
                    onNavigateToRegister = { navController.navigate(Screen.Register.route) }
                )
            }

            // 4. Register
            composable(Screen.Register.route) {
                RegisterScreen(
                    onRegisterSuccess = {
                        navController.navigate(Screen.Home.route) { popUpTo(0) }
                    },
                    onNavigateToLogin = { navController.popBackStack() }
                )
            }

            // --- MENU UTAMA (BOTTOM BAR) ---

            // 5. Home Route
            composable(Screen.Home.route) {
                HomeScreen(navController = navController) // Pass navController ke sini
            }

            // 6. Maps
            composable(Screen.Maps.route) {
                MapsScreen(
                    onMarkerClick = { reportId ->
                        navController.navigate(Screen.DetailReport.createRoute(reportId))
                    }
                )
            }

            // 7. Evacuation List (Menu Baru)
            composable(Screen.EvacuationList.route) {
                EvacuationListScreen(
                    onNavigateToUpdate = { reportId ->
                        // Saat kartu diklik, pindah ke layar update status
                        navController.navigate(Screen.RescueUpdate.createRoute(reportId))
                    }
                )
            }

            // 8. Profile
            composable(Screen.Profile.route) {
                ProfileScreen(
                    onLogout = {
                        navController.navigate(Screen.Login.route) { popUpTo(0) }
                    },
                    onReportClick = { reportId ->
                        navController.navigate(Screen.DetailReport.createRoute(reportId))
                    }
                )
            }

            // --- LAYAR LAIN ---

            // 9. Lapor (Full Screen)
            composable(Screen.CreateReport.route) {
                CreateReportScreen(
                    onBack = { navController.popBackStack() }
                )
            }

            // 10. Detail & Update
            composable(Screen.DetailReport.route) { backStackEntry ->
                val reportId = backStackEntry.arguments?.getString("reportId") ?: ""
                DetailScreen(
                    reportId = reportId,
                    onBack = { navController.popBackStack() },
                    onNavigateToRescue = { id ->
                        navController.navigate(Screen.RescueUpdate.createRoute(id))
                    }
                )
            }

            composable(Screen.RescueUpdate.route) { backStackEntry ->
                val reportId = backStackEntry.arguments?.getString("reportId") ?: ""
                RescueUpdateScreen(
                    reportId = reportId,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}