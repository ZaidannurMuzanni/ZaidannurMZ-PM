package com.example.petrescue.ui.screens.register

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.petrescue.data.repository.AuthRepository
import com.example.petrescue.di.Injection
import kotlinx.coroutines.launch

class RegisterViewModel(
    private val repository: AuthRepository = Injection.provideAuthRepository()
) : ViewModel() {

    var name by mutableStateOf("")
    var email by mutableStateOf("")
    var phone by mutableStateOf("")
    var password by mutableStateOf("")

    var isLoading by mutableStateOf(false)
    var errorMessage by mutableStateOf<String?>(null)
    var registerSuccess by mutableStateOf(false)

    fun onRegister() {
        if (name.isBlank() || email.isBlank() || password.isBlank()) {
            errorMessage = "Mohon isi semua data"
            return
        }

        isLoading = true
        errorMessage = null

        viewModelScope.launch {
            // Repository register sudah termasuk login otomatis
            val result = repository.register(name, email, password, phone)
            isLoading = false

            if (result.isSuccess) {
                registerSuccess = true
            } else {
                errorMessage = "Gagal Daftar: ${result.exceptionOrNull()?.message}"
            }
        }
    }
}