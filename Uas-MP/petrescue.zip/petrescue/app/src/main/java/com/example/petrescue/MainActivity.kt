package com.example.petrescue

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.petrescue.data.remote.AppwriteClient
import com.example.petrescue.ui.navigation.AppNavigation
import com.example.petrescue.ui.theme.PetRescueTheme

// KUNCI: Harus ada "class MainActivity" dan ": ComponentActivity()"
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            AppwriteClient.init(applicationContext)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        setContent {
            PetRescueTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}