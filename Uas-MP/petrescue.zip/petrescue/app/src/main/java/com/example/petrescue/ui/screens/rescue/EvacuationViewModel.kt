package com.example.petrescue.ui.screens.rescue

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.petrescue.data.remote.AppwriteClient
import io.appwrite.Query
import kotlinx.coroutines.launch

// Model Data Khusus List Evakuasi
data class EvacuationItem(
    val id: String,
    val title: String,
    val locationName: String, // Bisa ambil dari deskripsi atau lat/lng string
    val status: String, // pending, in_progress, rescued
    val imageId: String,
    val timeAgo: String, // Dummy dulu atau hitung dari createdAt
    val volunteerName: String = "Unassigned" // Placeholder
)

class EvacuationViewModel : ViewModel() {

    var allReports by mutableStateOf<List<EvacuationItem>>(emptyList())
    var filteredReports by mutableStateOf<List<EvacuationItem>>(emptyList())
    var isLoading by mutableStateOf(false)

    // State Filter & Search
    var searchQuery by mutableStateOf("")
    var selectedFilter by mutableStateOf("All") // All, Waiting, In Progress, Safe

    init {
        fetchEvacuations()
    }

    fun fetchEvacuations() {
        isLoading = true
        viewModelScope.launch {
            try {
                // Ambil data dari Appwrite
                val response = AppwriteClient.databases.listDocuments(
                    databaseId = "69638648002715e50d35", // Sesuaikan ID Database
                    collectionId = "reports",
                    queries = listOf(Query.orderDesc("\$createdAt"))
                )

                val items = response.documents.map { doc ->
                    val data = doc.data
                    val status = data["status"] as? String ?: "pending"

                    EvacuationItem(
                        id = doc.id,
                        title = data["title"] as? String ?: "Unknown Pet",
                        locationName = data["description"] as? String ?: "Lokasi tidak detail",
                        status = status,
                        imageId = data["imageId"] as? String ?: "",
                        timeAgo = "Baru saja", // Nanti bisa pakai fungsi format waktu
                        volunteerName = if (status == "in_progress") "Tim Rescue" else "Unassigned"
                    )
                }

                allReports = items
                applyFilters()

            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }

    // Logic Filtering di Client Side
    fun onSearchQueryChange(query: String) {
        searchQuery = query
        applyFilters()
    }

    fun onFilterSelected(filter: String) {
        selectedFilter = filter
        applyFilters()
    }

    private fun applyFilters() {
        filteredReports = allReports.filter { item ->
            // 1. Filter Search
            val matchesSearch = item.title.contains(searchQuery, ignoreCase = true) ||
                    item.id.contains(searchQuery, ignoreCase = true)

            // 2. Filter Status Tab
            val matchesStatus = when (selectedFilter) {
                "Waiting" -> item.status == "pending"
                "In Progress" -> item.status == "in_progress"
                "Safe" -> item.status == "rescued"
                else -> true // "All"
            }

            matchesSearch && matchesStatus
        }
    }
}