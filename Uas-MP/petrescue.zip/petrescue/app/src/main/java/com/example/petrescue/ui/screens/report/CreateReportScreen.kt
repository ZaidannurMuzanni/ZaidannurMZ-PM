package com.example.petrescue.ui.screens.report

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Pets
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.petrescue.ui.theme.RescueGreen
import com.example.petrescue.ui.theme.RescueOrange
import com.google.android.gms.location.LocationServices

@SuppressLint("MissingPermission")
@Composable
fun CreateReportScreen(
    viewModel: ReportViewModel = viewModel(),
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }

    // State Lokal untuk UI Chips
    var selectedAnimal by remember { mutableStateOf("Anjing") }
    var selectedCondition by remember { mutableStateOf("Injured") }

    // Update ViewModel saat state lokal berubah
    LaunchedEffect(selectedAnimal, selectedCondition) {
        // Otomatis isi judul jika kosong atau format lama
        if (viewModel.title.isEmpty() || viewModel.title.contains("-")) {
            viewModel.title = "$selectedAnimal - $selectedCondition"
        }
        // Mapping kondisi ke severity
        viewModel.severity = if (selectedCondition == "Injured") "critical" else "medium"
    }

    // --- LAUNCHERS ---
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> viewModel.imageUri = uri }
    )

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
        onResult = { permissions ->
            val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                    permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
            if (granted) {
                fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                    if (loc != null) {
                        viewModel.latitude = loc.latitude
                        viewModel.longitude = loc.longitude
                        Toast.makeText(context, "Lokasi berhasil diperbarui!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    )

    // Handle Success
    LaunchedEffect(viewModel.uploadSuccess) {
        if (viewModel.uploadSuccess) {
            Toast.makeText(context, "Laporan Terkirim!", Toast.LENGTH_LONG).show()
            onBack()
        }
    }

    Scaffold(
        bottomBar = {
            // Sticky Bottom Button
            Button(
                onClick = { viewModel.submitReport(context) },
                enabled = !viewModel.isLoading,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RescueOrange), // Orange untuk Emergency
                shape = RoundedCornerShape(12.dp),
                elevation = ButtonDefaults.buttonElevation(8.dp)
            ) {
                if (viewModel.isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Icon(Icons.Default.Send, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("KIRIM LAPORAN", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        },
        containerColor = Color(0xFFF8F9FA) // Background Putih Tulang
    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 16.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text("Report Pet", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }

            // 1. PHOTO UPLOAD SECTION (Dashed Border)
            Text("Pet Photo", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFE8F5E9)) // Hijau muda background
                    .clickable {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                // Dashed Border Canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val stroke = Stroke(
                        width = 4f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 20f), 0f)
                    )
                    drawRoundRect(
                        color = RescueGreen,
                        style = stroke,
                        cornerRadius = CornerRadius(16.dp.toPx())
                    )
                }

                if (viewModel.imageUri != null) {
                    Image(
                        painter = rememberAsyncImagePainter(viewModel.imageUri),
                        contentDescription = "Foto",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Tombol Ganti Foto Kecil
                    Box(modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp)) {
                        FloatingActionButton(
                            onClick = { photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            containerColor = Color.White,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = RescueGreen)
                        }
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(RescueGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Upload Photo", fontWeight = FontWeight.Bold, color = Color.Black)
                        Text("Tap to open gallery/camera", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 2. ANIMAL TYPE CHIPS
            Text("Animal Type", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                AnimalTypeChip(icon = Icons.Outlined.Pets, label = "Anjing", isSelected = selectedAnimal == "Anjing") { selectedAnimal = "Anjing" }
                AnimalTypeChip(icon = Icons.Outlined.Pets, label = "Kucing", isSelected = selectedAnimal == "Kucing") { selectedAnimal = "Kucing" }
                AnimalTypeChip(icon = Icons.Outlined.Pets, label = "Lainnya", isSelected = selectedAnimal == "Lainnya") { selectedAnimal = "Lainnya" }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 3. CONDITION CARDS
            Text("Condition", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ConditionCard(
                    title = "Injured / Critical",
                    isSelected = selectedCondition == "Injured",
                    color = Color(0xFFFFEBEE), // Merah muda
                    borderColor = Color(0xFFD32F2F),
                    icon = Icons.Default.LocalHospital,
                    onClick = { selectedCondition = "Injured" }
                )
                ConditionCard(
                    title = "Trapped / Needs Rescue",
                    isSelected = selectedCondition == "Trapped",
                    color = Color(0xFFE3F2FD), // Biru muda
                    borderColor = Color(0xFF1976D2),
                    icon = Icons.Default.Warning,
                    onClick = { selectedCondition = "Trapped" }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 4. LOCATION PREVIEW CARD
            Text("Location", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
            Card(
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.height(180.dp)) {
                    // Placeholder Map Image (Box Abu + Grid)
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFFE0E0E0)),
                        contentAlignment = Alignment.Center
                    ) {
                        // Grid pattern dummy
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val step = 50.dp.toPx()
                            for(i in 0..(size.width/step).toInt()) {
                                drawLine(Color.White, start = androidx.compose.ui.geometry.Offset(i*step, 0f), end = androidx.compose.ui.geometry.Offset(i*step, size.height), strokeWidth = 2f)
                            }
                            for(i in 0..(size.height/step).toInt()) {
                                drawLine(Color.White, start = androidx.compose.ui.geometry.Offset(0f, i*step), end = androidx.compose.ui.geometry.Offset(size.width, i*step), strokeWidth = 2f)
                            }
                        }

                        // Icon Pin
                        Icon(
                            Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = Color.Red,
                            modifier = Modifier.size(48.dp).offset(y = (-12).dp)
                        )
                    }

                    // Bottom Bar Address
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.7f))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Navigation, contentDescription = null, tint = RescueGreen, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (viewModel.latitude == 0.0) "Ketuk untuk ambil lokasi GPS" else "${viewModel.latitude}, ${viewModel.longitude}",
                                color = Color.White,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1
                            )
                        }
                    }

                    // Klik area untuk update lokasi
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                if (ActivityCompat.checkSelfPermission(
                                        context,
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                    ) != PackageManager.PERMISSION_GRANTED
                                ) {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                } else {
                                    fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                                        if (loc != null) {
                                            viewModel.latitude = loc.latitude
                                            viewModel.longitude = loc.longitude
                                            Toast.makeText(context, "Lokasi diperbarui!", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            }
                    )
                }
            }

            // Tombol Teks Hijau dibawah peta
            TextButton(
                onClick = { /* Opsional: Buka peta full screen untuk pick manual */ },
                modifier = Modifier.padding(top = 4.dp)
            ) {
                Icon(Icons.Default.MyLocation, contentDescription = null, tint = RescueGreen, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Update Pin Lokasi", color = RescueGreen, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 5. ADDITIONAL NOTES
            Text("Additional Notes", fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
            OutlinedTextField(
                value = viewModel.description,
                onValueChange = { viewModel.description = it },
                placeholder = { Text("Warna kalung, ciri khusus, atau info akses lokasi...") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = RescueGreen,
                    unfocusedBorderColor = Color.LightGray
                )
            )

            if (viewModel.errorMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(viewModel.errorMessage!!, color = MaterialTheme.colorScheme.error)
            }

            Spacer(modifier = Modifier.height(100.dp)) // Ruang untuk tombol sticky
        }
    }
}

// --- HELPER COMPONENTS ---

@Composable
fun AnimalTypeChip(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) RescueGreen else Color(0xFFF0F0F0),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color.White else Color.Black,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) Color.White else Color.Black
            )
        }
    }
}

@Composable
fun ConditionCard(
    title: String,
    isSelected: Boolean,
    color: Color,
    borderColor: Color,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, borderColor) else null
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = borderColor)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(title, fontWeight = FontWeight.Bold, color = Color.Black.copy(alpha = 0.8f))
            Spacer(modifier = Modifier.weight(1f))
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(selectedColor = borderColor)
            )
        }
    }
}