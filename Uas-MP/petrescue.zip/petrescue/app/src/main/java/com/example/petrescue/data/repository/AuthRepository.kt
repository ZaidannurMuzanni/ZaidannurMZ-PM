package com.example.petrescue.data.repository

import com.example.petrescue.data.model.User
import com.example.petrescue.data.remote.AppwriteClient
import io.appwrite.ID
import io.appwrite.exceptions.AppwriteException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AuthRepository {

    // Login Function
    suspend fun login(email: String, pass: String): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                // 1. Create Session
                AppwriteClient.account.createEmailPasswordSession(email, pass)

                // 2. Get Account Details
                val account = AppwriteClient.account.get()

                // 3. Return User (Idealnya fetch role dari Database collection 'users' juga,
                // tapi untuk tahap awal kita pakai data akun dulu)
                val user = User(
                    id = account.id,
                    name = account.name,
                    email = account.email
                )
                Result.success(user)
            } catch (e: AppwriteException) {
                Result.failure(e)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    // Register Function
    suspend fun register(name: String, email: String, pass: String, phone: String): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                // 1. Create Account
                AppwriteClient.account.create(ID.unique(), email, pass, name)

                // 2. Auto Login
                login(email, pass)

                // TODO (Nanti): Simpan data tambahan (phone, role) ke Collection 'users'

                val user = User(id = "temp", name = name, email = email, phone = phone)
                Result.success(user)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    // Check Session (untuk Splash Screen)
    suspend fun checkSession(): Result<User> {
        return withContext(Dispatchers.IO) {
            try {
                val account = AppwriteClient.account.get()
                Result.success(User(account.id, account.name, account.email))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
    }

    suspend fun logout() {
        withContext(Dispatchers.IO) {
            try {
                AppwriteClient.account.deleteSession("current")
            } catch (_: Exception) { }
        }
    }
}