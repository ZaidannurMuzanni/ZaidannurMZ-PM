package com.example.petrescue.ui.screens.login

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.petrescue.data.repository.AuthRepository
import com.example.petrescue.di.Injection
import kotlinx.coroutines.launch

class LoginViewModel(
    private val repository: AuthRepository = Injection.provideAuthRepository()
) : ViewModel() {

    // State untuk Input
    var email by mutableStateOf("")
    var password by mutableStateOf("")

    // State untuk UI (Loading & Error)
    var isLoading by mutableStateOf(false)
    var errorMessage by mutableStateOf<String?>(null)
    var loginSuccess by mutableStateOf(false)

    fun onLogin() {
        if (email.isBlank() || password.isBlank()) {
            errorMessage = "Email dan password tidak boleh kosong"
            return
        }

        isLoading = true
        errorMessage = null

        viewModelScope.launch {
            val result = repository.login(email, password)
            isLoading = false

            if (result.isSuccess) {
                loginSuccess = true
            } else {
                errorMessage = result.exceptionOrNull()?.message ?: "Login Gagal"
            }
        }
    }
}