package com.example.petrescue.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.petrescue.ui.components.ActiveReportItem
import com.example.petrescue.ui.components.EmergencyBanner
import com.example.petrescue.ui.components.QuickMenuButton
import com.example.petrescue.ui.navigation.Screen
import com.example.petrescue.ui.theme.RescueBlue
import com.example.petrescue.ui.theme.RescueGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel = viewModel()
) {
    LaunchedEffect(Unit) {
        viewModel.fetchHomeData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = RescueGreen, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Pets, contentDescription = null, modifier = Modifier.padding(6.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("PetRescue", fontWeight = FontWeight.Bold, color = RescueBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF8F9FA))
            )
        }
    ) { paddingValues ->

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8F9FA))
                .padding(paddingValues)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // 1. BANNER DINAMIS
            item {
                EmergencyBanner(
                    isEmergency = viewModel.isEmergency,
                    activeCount = viewModel.activeCount
                )
            }

            // 2. MENU CEPAT
            item {
                Text("Menu Cepat", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = RescueBlue)
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    QuickMenuButton(
                        icon = Icons.Default.ReportProblem,
                        title = "Lapor",
                        color = Color(0xFFE57373),
                        onClick = { navController.navigate(Screen.CreateReport.route) }
                    )
                    QuickMenuButton(
                        icon = Icons.Default.Map,
                        title = "Peta",
                        color = Color(0xFF64B5F6),
                        onClick = { navController.navigate(Screen.Maps.route) }
                    )
                    QuickMenuButton(
                        icon = Icons.Default.HealthAndSafety,
                        title = "Evakuasi",
                        color = Color(0xFFFFB74D),
                        onClick = { navController.navigate(Screen.EvacuationList.route) }
                    )
                }
            }

            // 3. LAPORAN TERBARU
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Laporan Terbaru", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = RescueBlue)
                    TextButton(onClick = { navController.navigate(Screen.Maps.route) }) {
                        Text("Lihat Peta", color = RescueGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (viewModel.isLoading) {
                item {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            } else if (viewModel.recentReports.isEmpty()) {
                item {
                    Text("Belum ada laporan aktif.", color = Color.Gray, modifier = Modifier.padding(8.dp))
                }
            } else {
                // DATA DARI DATABASE
                items(viewModel.recentReports) { report ->
                    ActiveReportItem(
                        title = report.title,
                        desc = report.description,
                        severity = report.severity,
                        imageId = report.imageId, // <--- ERROR HILANG DISINI JIKA LANGKAH 1 DILAKUKAN
                        onClick = {
                            navController.navigate(Screen.DetailReport.createRoute(report.id))
                        }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(80.dp)) }
        }
    }
}