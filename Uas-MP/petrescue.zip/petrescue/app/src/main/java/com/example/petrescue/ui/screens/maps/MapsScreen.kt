package com.example.petrescue.ui.screens.maps

import android.graphics.drawable.Drawable
import android.preference.PreferenceManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.petrescue.R // Pastikan import R dari package kamu
import com.example.petrescue.ui.theme.RescueGreen
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

@Composable
fun MapsScreen(
    viewModel: MapsViewModel = viewModel(),
    onMarkerClick: (String) -> Unit
) {
    val context = LocalContext.current

    // State untuk kontrol Peta
    var mapViewReference by remember { mutableStateOf<MapView?>(null) }

    // State UI
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("Semua") } // Semua, Anjing, Kucing, Kritis
    var selectedReport by remember { mutableStateOf<ReportMapItem?>(null) } // Untuk Bottom Card

    // 1. Setup Data & Config
    LaunchedEffect(Unit) {
        viewModel.fetchReports()
    }
    remember {
        Configuration.getInstance().load(context, PreferenceManager.getDefaultSharedPreferences(context))
        Configuration.getInstance().userAgentValue = context.packageName
        true
    }

    // 2. Filter Logic
    val filteredReports = viewModel.reports.filter { report ->
        val matchesSearch = report.title.contains(searchQuery, ignoreCase = true) ||
                report.description.contains(searchQuery, ignoreCase = true)

        val matchesFilter = when (selectedFilter) {
            "Anjing" -> report.title.contains("Anjing", ignoreCase = true)
            "Kucing" -> report.title.contains("Kucing", ignoreCase = true)
            "Kritis" -> report.severity == "high" || report.severity == "critical"
            else -> true
        }
        matchesSearch && matchesFilter
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // --- LAYER 1: PETA OSMDROID ---
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                MapView(ctx).apply {
                    setTileSource(TileSourceFactory.MAPNIK)
                    setMultiTouchControls(true)

                    // --- HILANGKAN TOMBOL ZOOM YANG DI LINGKARAN MERAH ---
                    zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)

                    controller.setZoom(13.0)
                    controller.setCenter(GeoPoint(-3.4406, 114.8289)) // Banjarbaru
                    mapViewReference = this
                }
            },
            update = { mapView ->
                mapView.overlays.clear() // Reset marker

                filteredReports.forEach { report ->
                    val marker = Marker(mapView)
                    marker.position = GeoPoint(report.lat, report.lng)
                    marker.title = report.title

                    // --- CUSTOM ICON LOGIC ---
                    // Logika untuk mengubah icon berdasarkan judul/jenis hewan
                    // Pastikan kamu punya file gambar di res/drawable (misal: ic_pin_dog.png)
                    val iconDrawable: Drawable? = try {
                        when {
                            // Cek Judul mengandung kata "Anjing"
                            report.title.contains("Anjing", ignoreCase = true) -> {
                                // Ganti R.drawable.ic_launcher_foreground dengan R.drawable.ic_pin_dog milikmu
                                ContextCompat.getDrawable(context, org.osmdroid.library.R.drawable.marker_default)
                            }
                            // Cek Judul mengandung kata "Kucing"
                            report.title.contains("Kucing", ignoreCase = true) -> {
                                // Ganti dengan R.drawable.ic_pin_cat milikmu
                                ContextCompat.getDrawable(context, org.osmdroid.library.R.drawable.marker_default)
                            }
                            // Cek Status Kritis
                            report.severity == "critical" || report.severity == "high" -> {
                                // Ganti dengan R.drawable.ic_pin_alert milikmu
                                ContextCompat.getDrawable(context, org.osmdroid.library.R.drawable.marker_default_focused_base)
                            }
                            else -> {
                                ContextCompat.getDrawable(context, org.osmdroid.library.R.drawable.marker_default)
                            }
                        }
                    } catch (e: Exception) {
                        // Fallback jika error
                        ContextCompat.getDrawable(context, org.osmdroid.library.R.drawable.marker_default)
                    }

                    // Set Icon ke Marker
                    if (iconDrawable != null) {
                        marker.icon = iconDrawable
                    }

                    // Logic Klik Marker
                    marker.setOnMarkerClickListener { _, _ ->
                        selectedReport = report // Munculkan Bottom Card
                        mapView.controller.animateTo(GeoPoint(report.lat, report.lng))
                        true
                    }

                    mapView.overlays.add(marker)
                }
                mapView.invalidate()
            }
        )

        // --- LAYER 2: TOP SEARCH BAR & FILTER ---
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(top = 16.dp, start = 16.dp, end = 16.dp)
        ) {
            // Search Bar (Dark Theme)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF1B2E26), // Hijau Gelap
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Icon(Icons.Default.Search, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(12.dp))
                    androidx.compose.foundation.text.BasicTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.White),
                        modifier = Modifier.weight(1f),
                        decorationBox = { innerTextField ->
                            if (searchQuery.isEmpty()) {
                                Text("Cari lokasi atau ID hewan...", color = Color.Gray)
                            }
                            innerTextField()
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Filter Chips
            val filters = listOf("Semua", "Anjing", "Kucing", "Kritis")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filters) { filter ->
                    val isSelected = selectedFilter == filter
                    val bgColor = if (isSelected) RescueGreen else Color(0xFF1B2E26)
                    val textColor = if (isSelected) Color.Black else Color.White

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = bgColor,
                        shadowElevation = 4.dp,
                        modifier = Modifier.clickable { selectedFilter = filter }
                    ) {
                        Text(
                            text = filter,
                            fontWeight = FontWeight.Bold,
                            color = textColor,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // --- LAYER 3: CUSTOM ZOOM BUTTONS (Kanan) ---
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SmallMapButton(Icons.Default.Add) {
                mapViewReference?.controller?.zoomIn()
            }
            SmallMapButton(Icons.Default.Remove) {
                mapViewReference?.controller?.zoomOut()
            }
            Spacer(modifier = Modifier.height(8.dp))
            SmallMapButton(Icons.Default.MyLocation) {
                // Reset ke Banjarbaru
                mapViewReference?.controller?.animateTo(GeoPoint(-3.4406, 114.8289))
            }
        }

        // --- LAYER 4: DETAIL CARD (Bottom Sheet) ---
        AnimatedVisibility(
            visible = selectedReport != null,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
                .padding(bottom = 80.dp) // Beri jarak untuk Bottom Navbar
        ) {
            selectedReport?.let { report ->
                PetMapDetailCard(
                    report = report,
                    onClose = { selectedReport = null },
                    onStartRescue = { onMarkerClick(report.id) }
                )
            }
        }

        if (viewModel.isLoading) {
            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = RescueGreen)
        }
    }
}

// --- COMPONENTS ---

@Composable
fun PetMapDetailCard(
    report: ReportMapItem,
    onClose: () -> Unit,
    onStartRescue: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2E24)), // Dark Green Theme
        elevation = CardDefaults.cardElevation(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Badge & Close
            Row(verticalAlignment = Alignment.CenterVertically) {
                val badgeColor = if (report.severity == "high" || report.severity == "critical") Color(0xFFD32F2F) else Color(0xFFFFB74D)
                Surface(color = badgeColor, shape = RoundedCornerShape(6.dp)) {
                    Text(
                        text = if (report.severity == "high") "NEEDS HELP" else report.severity.uppercase(),
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row {
                // Foto Hewan dari Appwrite
                if (report.imageId.isNotEmpty()) {
                    // Ganti Project ID & Bucket ID sesuai database kamu
                    val imageUrl = "https://nyc.cloud.appwrite.io/v1/storage/buckets/6963890d002b17d6566e/files/${report.imageId}/view?project=696384340004a84c832d"
                    AsyncImage(
                        model = imageUrl,
                        contentDescription = null,
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Gray),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Pets, contentDescription = null, tint = Color.White)
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Info Teks
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = report.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1
                    )
                    Text(
                        text = report.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Lokasi Terpantau", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Tombol Aksi
            Button(
                onClick = onStartRescue,
                colors = ButtonDefaults.buttonColors(containerColor = RescueGreen),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Default.Navigation, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Start Rescue", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SmallMapButton(icon: ImageVector, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1B2E26), // Hijau Gelap
        shadowElevation = 4.dp,
        modifier = Modifier.size(40.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = Color.White)
        }
    }
}