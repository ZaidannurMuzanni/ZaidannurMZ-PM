package com.example.petrescue.ui.screens.profile

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.petrescue.data.remote.AppwriteClient
import com.example.petrescue.ui.screens.rescue.EvacuationItem
import io.appwrite.Query
import io.appwrite.models.InputFile
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class ProfileViewModel : ViewModel() {

    // Data User
    var userName by mutableStateOf("Loading...")
    var userEmail by mutableStateOf("")
    var userAvatarUrl by mutableStateOf<String?>(null)
    var userRole by mutableStateOf("Relawan • Volunteer")

    // Statistik
    var rescueCount by mutableStateOf(0)
    var reportCount by mutableStateOf(0)
    var badgeCount by mutableStateOf(5)

    // Lists
    var assignedTasks by mutableStateOf<List<EvacuationItem>>(emptyList())
    var myReports by mutableStateOf<List<EvacuationItem>>(emptyList())

    var isLoading by mutableStateOf(false)

    init {
        fetchProfileData()
    }

    fun fetchProfileData() {
        isLoading = true
        viewModelScope.launch {
            try {
                // 1. Get Account & Prefs (Avatar)
                val account = AppwriteClient.account.get()
                userName = account.name
                userEmail = account.email

                // Cek apakah ada avatarId di preferences
                val prefs = AppwriteClient.account.getPrefs()
                val avatarId = prefs.data["avatarId"] as? String

                if (avatarId != null) {
                    // Ganti Project ID & Bucket ID sesuai konfigurasi Anda
                    userAvatarUrl = "https://nyc.cloud.appwrite.io/v1/storage/buckets/6963890d002b17d6566e/files/$avatarId/view?project=696384340004a84c832d"
                }

                // 2. Fetch My Reports (Yang saya laporin)
                val reportsRes = AppwriteClient.databases.listDocuments(
                    databaseId = "69638648002715e50d35",
                    collectionId = "reports",
                    queries = listOf(Query.equal("reporterId", account.id), Query.orderDesc("\$createdAt"))
                )

                // 3. Fetch Assigned Tasks (Yang statusnya in_progress)
                val assignedRes = AppwriteClient.databases.listDocuments(
                    databaseId = "69638648002715e50d35",
                    collectionId = "reports",
                    queries = listOf(Query.equal("status", "in_progress"))
                )

                // 4. Mapping Data (FIX ERROR DISINI: Casting ke Document<Map<String, Any>>)
                myReports = reportsRes.documents.map {
                    mapToEvacuationItem(it as io.appwrite.models.Document<Map<String, Any>>)
                }

                assignedTasks = assignedRes.documents.map {
                    mapToEvacuationItem(it as io.appwrite.models.Document<Map<String, Any>>)
                }

                // 5. Update Stats
                reportCount = reportsRes.total.toInt()
                rescueCount = assignedTasks.filter { it.status == "rescued" }.size

            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }

    // Fungsi Upload Foto Profile
    fun uploadProfilePicture(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                isLoading = true
                val contentResolver = context.contentResolver
                val file = File(context.cacheDir, "temp_avatar.jpg")
                val inputStream = contentResolver.openInputStream(uri)
                val outputStream = FileOutputStream(file)
                inputStream?.copyTo(outputStream)

                // 1. Upload ke Bucket
                val inputFile = InputFile.fromFile(file)
                val uploaded = AppwriteClient.storage.createFile(
                    bucketId = "6963890d002b17d6566e",
                    fileId = io.appwrite.ID.unique(),
                    file = inputFile
                )

                // 2. Simpan ID File ke User Preferences
                val currentPrefs = AppwriteClient.account.getPrefs().data.toMutableMap()
                currentPrefs["avatarId"] = uploaded.id
                AppwriteClient.account.updatePrefs(currentPrefs)

                // 3. Update UI Langsung
                userAvatarUrl = "https://nyc.cloud.appwrite.io/v1/storage/buckets/6963890d002b17d6566e/files/${uploaded.id}/view?project=696384340004a84c832d"

                Toast.makeText(context, "Foto Profil Diperbarui!", Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Gagal upload: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                isLoading = false
            }
        }
    }

    fun logout(onLogoutSuccess: () -> Unit) {
        viewModelScope.launch {
            try {
                AppwriteClient.account.deleteSession("current")
                onLogoutSuccess()
            } catch (e: Exception) {
                onLogoutSuccess()
            }
        }
    }

    // Helper Mapping (FIX ERROR DISINI: Tambahkan Generic Type <Map<String, Any>>)
    private fun mapToEvacuationItem(doc: io.appwrite.models.Document<Map<String, Any>>): EvacuationItem {
        val data = doc.data // Sekarang compiler tahu 'data' adalah Map
        return EvacuationItem(
            id = doc.id,
            title = data["title"] as? String ?: "Unknown",
            locationName = "Sector A • Storm Surge",
            status = data["status"] as? String ?: "pending",
            imageId = data["imageId"] as? String ?: "",
            timeAgo = "Recently"
        )
    }
}