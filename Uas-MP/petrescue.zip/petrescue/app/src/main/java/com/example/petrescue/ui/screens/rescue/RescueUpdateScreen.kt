package com.example.petrescue.ui.screens.rescue

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.petrescue.ui.theme.RescueGreen
import com.example.petrescue.ui.theme.RescueOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RescueUpdateScreen(
    reportId: String,
    viewModel: RescueViewModel = viewModel(),
    onBack: () -> Unit
) {
    // 1. PANGGIL DATA SAAT LAYAR DIBUKA (Agar Header Tidak Dummy)
    LaunchedEffect(reportId) {
        viewModel.fetchReportDetails(reportId)
    }

    LaunchedEffect(viewModel.isSuccess) {
        if (viewModel.isSuccess) {
            onBack()
        }
    }

    // Warna Status
    val colorPending = RescueOrange
    val colorProgress = Color(0xFF2196F3) // Biru
    val colorSafe = RescueGreen // Hijau

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Evacuation Status", fontWeight = FontWeight.Bold)
                        Text("ID: #${reportId.takeLast(4).uppercase()}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color(0xFFF9F9F9))
            )
        },
        // --- 2. STICKY BOTTOM BUTTON (SAFE AREA FIXED) ---
        bottomBar = {
            Surface(
                shadowElevation = 16.dp,
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Teks Tombol Dinamis
                val buttonText = when(viewModel.status) {
                    "in_progress" -> "SELESAIKAN MISI (FINISH)"
                    "rescued" -> "DATA SUDAH AMAN"
                    else -> "MULAI EVAKUASI (START)"
                }

                // Warna Tombol Dinamis (Default Hijau, tapi bisa berubah biar intuitif)
                val btnColor = if (viewModel.status == "in_progress") colorProgress else RescueGreen

                Column(
                    modifier = Modifier
                        .navigationBarsPadding() // Mencegah tertutup tombol HP
                        .padding(16.dp)
                ) {
                    Button(
                        onClick = { viewModel.submitUpdate(reportId) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = RescueGreen, // Permintaan: Tema Hijau
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp),
                        elevation = ButtonDefaults.buttonElevation(4.dp),
                        enabled = !viewModel.isLoading
                    ) {
                        if (viewModel.isLoading) {
                            CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(24.dp))
                        } else {
                            Text(buttonText, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null)
                        }
                    }
                }
            }
        },
        containerColor = Color(0xFFF9F9F9)
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // 3. HEADER CARD (DATA REAL DARI VIEWMODEL)
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFEEEEEE)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Pets, contentDescription = null, tint = Color.Gray)
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        // DATA REAL: Judul Hewan
                        Text(viewModel.animalTitle, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, null, tint = Color.Gray, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            // DATA REAL: Lokasi
                            Text(viewModel.locationName, color = Color.Gray, fontSize = 12.sp, maxLines = 1)
                        }
                    }

                    // Badge Severity Dinamis
                    val severityColor = if (viewModel.severity == "critical" || viewModel.severity == "high") Color.Red else RescueGreen
                    Surface(
                        color = severityColor.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = viewModel.severity.uppercase(),
                            color = severityColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 4. TIMELINE SELECTOR (Status Real dari ViewModel)
            Text("Update Progress", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(bottom = 12.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {

                    // A. WAITING
                    TimelineItem(
                        title = "Waiting",
                        subtitle = "Laporan diterima",
                        icon = Icons.Default.PendingActions,
                        itemColor = colorPending,
                        isSelected = viewModel.status == "pending", // Cek status real
                        isLast = false,
                        onClick = { viewModel.status = "pending" }
                    )

                    // B. IN EVACUATION
                    TimelineItem(
                        title = "In Evacuation",
                        subtitle = "Tim menuju lokasi",
                        icon = Icons.Default.LocalShipping,
                        itemColor = colorProgress,
                        isSelected = viewModel.status == "in_progress", // Cek status real
                        isLast = false,
                        onClick = { viewModel.status = "in_progress" }
                    )

                    // C. SAFE
                    TimelineItem(
                        title = "Safe / Rescued",
                        subtitle = "Hewan aman di shelter",
                        icon = Icons.Default.CheckCircle,
                        itemColor = colorSafe,
                        isSelected = viewModel.status == "rescued", // Cek status real
                        isLast = true,
                        onClick = { viewModel.status = "rescued" }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 5. FORM INPUT
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.EditNote, contentDescription = null, tint = RescueGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Rescue Details", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = viewModel.notes,
                onValueChange = { viewModel.notes = it },
                label = { Text("Catatan Lapangan") },
                placeholder = { Text("Kondisi hewan, kendala, atau info medis...") },
                modifier = Modifier.fillMaxWidth().height(120.dp),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    disabledContainerColor = Color.White,
                    focusedBorderColor = RescueGreen,
                    unfocusedBorderColor = Color.LightGray
                )
            )

            // Input Estimasi hanya muncul jika proses sedang berlangsung
            AnimatedVisibility(
                visible = viewModel.status == "in_progress",
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = viewModel.estimatedTime,
                        onValueChange = { viewModel.estimatedTime = it },
                        label = { Text("Estimasi Waktu Selesai") },
                        placeholder = { Text("Contoh: 15 Menit") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        trailingIcon = { Icon(Icons.Default.Timer, null) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            disabledContainerColor = Color.White,
                            focusedBorderColor = colorProgress,
                            unfocusedBorderColor = Color.LightGray
                        )
                    )
                }
            }

            // Spacer Extra agar konten terakhir tidak tertutup sticky button
            Spacer(modifier = Modifier.height(100.dp))
        }
    }
}

// --- REUSABLE TIMELINE ITEM ---
@Composable
fun TimelineItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    itemColor: Color,
    isSelected: Boolean,
    isLast: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(40.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) itemColor else Color(0xFFF0F0F0))
                    .border(
                        width = if (isSelected) 0.dp else 2.dp,
                        color = if (isSelected) Color.Transparent else Color.LightGray,
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) Color.White else Color.Gray,
                    modifier = Modifier.size(16.dp)
                )
            }

            if (!isLast) {
                Canvas(
                    modifier = Modifier
                        .width(2.dp)
                        .height(40.dp)
                        .padding(top = 4.dp)
                ) {
                    drawLine(
                        color = if (isSelected) itemColor.copy(alpha = 0.5f) else Color.LightGray.copy(alpha = 0.5f),
                        start = Offset(0f, 0f),
                        end = Offset(0f, size.height),
                        strokeWidth = 4f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.padding(top = 4.dp).weight(1f)) {
            Text(
                text = title,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) itemColor else Color.Black,
                fontSize = 16.sp
            )
            Text(text = subtitle, fontSize = 12.sp, color = Color.Gray)

            if (isSelected) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "● Aktif", fontSize = 12.sp, color = itemColor, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}