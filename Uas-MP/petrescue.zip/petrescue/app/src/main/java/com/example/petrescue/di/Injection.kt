package com.example.petrescue.di

import com.example.petrescue.data.repository.AuthRepository
import com.example.petrescue.data.repository.ReportRepository // Import ini

object Injection {
    fun provideAuthRepository(): AuthRepository {
        return AuthRepository()
    }

    // Tambahkan ini
    fun provideReportRepository(): ReportRepository {
        return ReportRepository()
    }
}