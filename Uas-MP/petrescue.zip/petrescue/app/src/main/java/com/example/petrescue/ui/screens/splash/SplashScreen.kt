package com.example.petrescue.ui.screens.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.petrescue.R // Pastikan R ter-import dari package aplikasi kamu
import com.example.petrescue.data.repository.AuthRepository
import com.example.petrescue.di.Injection
import com.example.petrescue.ui.theme.RescueDarkBg
import com.example.petrescue.ui.theme.RescueGreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(
    onNavigateToHome: () -> Unit,
    onNavigateToLogin: () -> Unit
) {
    val repository = Injection.provideAuthRepository()

    // State untuk animasi progress bar (0.0f sampai 1.0f)
    val progressAnim = remember { Animatable(0f) }

    LaunchedEffect(true) {
        // 1. Jalankan animasi progress bar
        launch {
            progressAnim.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 2500, easing = LinearEasing)
            )
        }

        // 2. Cek sesi user di background
        val result = repository.checkSession()

        // 3. Tunggu agar animasi selesai terlihat
        delay(2500)

        // 4. Navigasi
        if (result.isSuccess) {
            onNavigateToHome()
        } else {
            onNavigateToLogin()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                // Gradient Background Gelap Elegan
                brush = Brush.verticalGradient(
                    colors = listOf(RescueDarkBg, Color(0xFF2C3E50), RescueDarkBg)
                )
            )
    ) {
        // --- BAGIAN TENGAH (LOGO & TEKS) ---
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // TAMPILKAN LOGO KAMU DI SINI
            Image(
                painter = painterResource(id = R.drawable.logo1),
                contentDescription = "Logo Aplikasi",
                modifier = Modifier
                    .size(150.dp) // Sesuaikan ukuran logo di sini (misal 120.dp - 150.dp)
                // .clip(RoundedCornerShape(16.dp)) // Hilangkan komentar jika ingin sudut logo melengkung
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Judul Besar
            Text(
                text = "PetRescue",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 36.sp,
                    letterSpacing = 1.sp
                ),
                color = Color.White
            )

            // Subjudul
            Text(
                text = "Saving Pets in Disaster",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = 0.8f)
            )
        }

        // --- BAGIAN BAWAH (LOADING BAR) ---
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 32.dp, vertical = 48.dp)
        ) {
            // Baris Teks Status & Persentase
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Initializing emergency network...",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.7f)
                )
                // Menampilkan persentase (0% - 100%)
                Text(
                    text = "${(progressAnim.value * 100).toInt()}%",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = RescueGreen
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Bar Hijau Neon
            LinearProgressIndicator(
                progress = progressAnim.value,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = RescueGreen,
                trackColor = Color.White.copy(alpha = 0.2f) // Warna track transparan
            )
        }
    }
}