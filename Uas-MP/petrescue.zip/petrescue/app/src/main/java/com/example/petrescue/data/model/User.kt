package com.example.petrescue.data.model

data class User(
    val id: String,
    val name: String,
    val email: String,
    val phone: String = "",
    val role: String = "public" // public atau rescuer
)