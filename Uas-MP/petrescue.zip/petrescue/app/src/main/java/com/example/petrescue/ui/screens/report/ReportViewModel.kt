package com.example.petrescue.ui.screens.report

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.petrescue.data.remote.AppwriteClient
import com.example.petrescue.data.repository.ReportRepository
import com.example.petrescue.di.Injection
import kotlinx.coroutines.launch

class ReportViewModel(
    private val repository: ReportRepository = Injection.provideReportRepository()
) : ViewModel() {

    // Form State
    var title by mutableStateOf("")
    var description by mutableStateOf("")
    var imageUri by mutableStateOf<Uri?>(null)
    var severity by mutableStateOf("medium") // low, medium, critical

    // Location State
    var latitude by mutableDoubleStateOf(0.0)
    var longitude by mutableDoubleStateOf(0.0)

    // UI State
    var isLoading by mutableStateOf(false)
    var errorMessage by mutableStateOf<String?>(null)
    var uploadSuccess by mutableStateOf(false)

    fun submitReport(context: Context) {
        if (title.isBlank() || description.isBlank() || imageUri == null || latitude == 0.0) {
            errorMessage = "Mohon lengkapi semua data, foto, dan lokasi."
            return
        }

        isLoading = true
        errorMessage = null

        viewModelScope.launch {
            try {
                // 0. Ambil User ID saat ini
                val user = AppwriteClient.account.get()

                // 1. Upload Gambar
                val uploadResult = repository.uploadImage(context, imageUri!!)

                if (uploadResult.isSuccess) {
                    val imageId = uploadResult.getOrNull()!!

                    // 2. Simpan Laporan
                    val reportResult = repository.createReport(
                        reporterId = user.id,
                        title = title,
                        desc = description,
                        imageId = imageId,
                        lat = latitude,
                        lng = longitude,
                        severity = severity
                    )

                    if (reportResult.isSuccess) {
                        uploadSuccess = true
                    } else {
                        errorMessage = "Gagal simpan data: ${reportResult.exceptionOrNull()?.message}"
                    }
                } else {
                    errorMessage = "Gagal upload gambar: ${uploadResult.exceptionOrNull()?.message}"
                }
            } catch (e: Exception) {
                errorMessage = "Error: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }
}