package com.example.petrescue.ui.screens.maps

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.petrescue.data.remote.AppwriteClient
import kotlinx.coroutines.launch

// 1. Data Class Updated (Wajib ada imageId)
data class ReportMapItem(
    val id: String,
    val title: String,
    val description: String,
    val lat: Double,
    val lng: Double,
    val severity: String,
    val imageId: String // <--- Field PENTING untuk menampilkan gambar
)

class MapsViewModel : ViewModel() {

    var reports by mutableStateOf<List<ReportMapItem>>(emptyList())
    var isLoading by mutableStateOf(false)

    init {
        fetchReports()
    }

    fun fetchReports() {
        isLoading = true
        viewModelScope.launch {
            try {
                // Pastikan Database ID & Collection ID sesuai dengan Project Appwrite Anda
                val response = AppwriteClient.databases.listDocuments(
                    databaseId = "69638648002715e50d35",
                    collectionId = "reports"
                )

                // 2. Mapping data dari Appwrite ke ReportMapItem
                val items = response.documents.map { doc ->
                    val data = doc.data
                    ReportMapItem(
                        id = doc.id,
                        title = data["title"] as? String ?: "Tanpa Judul",
                        description = data["description"] as? String ?: "-",
                        lat = (data["latitude"] as? Number)?.toDouble() ?: 0.0,
                        lng = (data["longitude"] as? Number)?.toDouble() ?: 0.0,
                        severity = data["severity"] as? String ?: "medium",
                        imageId = data["imageId"] as? String ?: "" // <--- Ambil ID Gambar dari database
                    )
                }
                reports = items
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
}