package com.example.petrescue.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Onboarding : Screen("onboarding")
    object Login : Screen("login")
    object Register : Screen("register")

    // --- MENU BOTTOM BAR ---
    object Home : Screen("home")
    object Maps : Screen("maps")
    object CreateReport : Screen("create_report")
    object EvacuationList : Screen("evacuation_list") // Menu Baru
    object Profile : Screen("profile")

    // --- SCREEN DETAIL ---
    object DetailReport : Screen("detail_report/{reportId}") {
        fun createRoute(reportId: String) = "detail_report/$reportId"
    }
    object RescueUpdate : Screen("rescue_update/{reportId}") {
        fun createRoute(reportId: String) = "rescue_update/$reportId"
    }
}