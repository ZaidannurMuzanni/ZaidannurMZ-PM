package com.example.petrescue.ui.screens.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.petrescue.data.remote.AppwriteClient
import com.example.petrescue.ui.screens.maps.ReportMapItem
import io.appwrite.Query
import kotlinx.coroutines.launch

class HomeViewModel : ViewModel() {

    var recentReports by mutableStateOf<List<ReportMapItem>>(emptyList())
    var isLoading by mutableStateOf(false)

    // Status Dashboard
    var activeCount by mutableStateOf(0)
    var isEmergency by mutableStateOf(false)

    init {
        fetchHomeData()
    }

    fun fetchHomeData() {
        isLoading = true
        viewModelScope.launch {
            try {
                // 1. Ambil Laporan (Terbaru, Limit 10)
                val response = AppwriteClient.databases.listDocuments(
                    databaseId = "69638648002715e50d35", // Pastikan ID Database Benar
                    collectionId = "reports",
                    queries = listOf(
                        Query.limit(10),
                        Query.orderDesc("\$createdAt")
                    )
                )

                // 2. Mapping Data (PENTING: imageId harus diambil)
                val items = response.documents.map { doc ->
                    val data = doc.data
                    ReportMapItem(
                        id = doc.id,
                        title = data["title"] as? String ?: "Tanpa Judul",
                        description = data["description"] as? String ?: "-",
                        lat = (data["latitude"] as? Number)?.toDouble() ?: 0.0,
                        lng = (data["longitude"] as? Number)?.toDouble() ?: 0.0,
                        severity = data["severity"] as? String ?: "medium",
                        imageId = data["imageId"] as? String ?: "" // <--- ERROR HILANG DISINI
                    )
                }

                recentReports = items

                // 3. Hitung Status Darurat
                val criticalReports = items.count {
                    it.severity == "high" || it.severity == "critical"
                }

                activeCount = items.size
                isEmergency = criticalReports > 0

            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
}