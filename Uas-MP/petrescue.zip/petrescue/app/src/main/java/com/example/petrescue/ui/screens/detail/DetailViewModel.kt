package com.example.petrescue.ui.screens.detail

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.petrescue.data.remote.AppwriteClient
import kotlinx.coroutines.launch

// 1. Data Class Report (Sesuai kebutuhan UI Detail)
data class Report(
    val id: String,
    val title: String,
    val description: String,
    val status: String,
    val severity: String,
    val imageId: String,
    val latitude: Double, // WAJIB ADA untuk Maps Intent
    val longitude: Double // WAJIB ADA untuk Maps Intent
)

class DetailViewModel : ViewModel() {

    var report by mutableStateOf<Report?>(null)
    var isLoading by mutableStateOf(false)
    var imageUrl by mutableStateOf<String?>(null)

    fun fetchReport(reportId: String) {
        isLoading = true
        viewModelScope.launch {
            try {
                val response = AppwriteClient.databases.getDocument(
                    databaseId = "69638648002715e50d35", // ID Database Kamu
                    collectionId = "reports",             // ID Collection Reports
                    documentId = reportId
                )

                val data = response.data

                // 2. Mapping Data dari Appwrite ke Object Report
                val reportData = Report(
                    id = response.id,
                    title = data["title"] as? String ?: "Tanpa Judul",
                    description = data["description"] as? String ?: "-",
                    status = data["status"] as? String ?: "pending",
                    severity = data["severity"] as? String ?: "medium",
                    imageId = data["imageId"] as? String ?: "",

                    // Mapping Koordinat (Mengatasi error 'Unresolved reference latitude/longitude')
                    // Appwrite mengembalikan angka sebagai Number, perlu dicast ke Double
                    latitude = (data["latitude"] as? Number)?.toDouble() ?: 0.0,
                    longitude = (data["longitude"] as? Number)?.toDouble() ?: 0.0
                )

                report = reportData

                // 3. Generate Image URL jika ada foto
                if (reportData.imageId.isNotEmpty()) {
                    // Ganti Project ID & Bucket ID sesuai konfigurasi Appwrite kamu
                    // Bucket ID: 6963890d002b17d6566e (Sesuai kode sebelumnya)
                    // Project ID: 696384340004a84c832d (Sesuai kode sebelumnya)
                    imageUrl = "https://nyc.cloud.appwrite.io/v1/storage/buckets/6963890d002b17d6566e/files/${reportData.imageId}/view?project=696384340004a84c832d"
                }

            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
}