package com.example.petrescue.data.repository

import android.content.Context
import android.net.Uri
import com.example.petrescue.data.remote.AppwriteClient
import io.appwrite.ID
import io.appwrite.models.InputFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class ReportRepository {

    private val db = AppwriteClient.databases
    private val storage = AppwriteClient.storage
    private val databaseId = "69638648002715e50d35"
    private val collectionId = "reports"
    private val bucketId = "6963890d002b17d6566e"

    // --- PERBAIKAN UTAMA DI SINI ---
    suspend fun uploadImage(context: Context, imageUri: Uri): Result<String> {
        return withContext(Dispatchers.IO) {
            try {
                // 1. Buka Stream dari ContentResolver (Virtual File)
                val contentResolver = context.contentResolver
                val inputStream = contentResolver.openInputStream(imageUri)
                    ?: return@withContext Result.failure(Exception("Gagal membuka file gambar dari galeri"))

                // 2. Buat File Sementara yang Unik di Cache Aplikasi
                // Menggunakan createTempFile agar nama file selalu unik dan tidak bentrok
                val tempFile = File.createTempFile("upload_${System.currentTimeMillis()}", ".jpg", context.cacheDir)

                // 3. Salin data dari Stream ke File Sementara
                val outputStream = FileOutputStream(tempFile)
                inputStream.use { input ->
                    outputStream.use { output ->
                        input.copyTo(output)
                    }
                }
                // (Block .use {} di atas otomatis menutup stream, memastikan data tersimpan utuh)

                // 4. Siapkan InputFile untuk Appwrite
                val inputFile = InputFile.fromFile(tempFile)

                // 5. Upload ke Appwrite Storage
                val response = storage.createFile(
                    bucketId = bucketId,
                    fileId = ID.unique(),
                    file = inputFile
                )

                // 6. Hapus file sampah (cache) agar HP user tidak penuh
                tempFile.delete()

                Result.success(response.id)
            } catch (e: Exception) {
                e.printStackTrace()
                Result.failure(e)
            }
        }
    }

    // Fungsi Create Report (Tidak Berubah)
    suspend fun createReport(
        reporterId: String,
        title: String,
        desc: String,
        imageId: String,
        lat: Double,
        lng: Double,
        severity: String
    ): Result<Boolean> {
        return withContext(Dispatchers.IO) {
            try {
                val data = mapOf(
                    "reporterId" to reporterId,
                    "title" to title,
                    "description" to desc,
                    "imageId" to imageId,
                    "latitude" to lat,
                    "longitude" to lng,
                    "status" to "pending",
                    "severity" to severity,
                    "createdAt" to System.currentTimeMillis().toString()
                )

                db.createDocument(
                    databaseId = databaseId,
                    collectionId = collectionId,
                    documentId = ID.unique(),
                    data = data
                )
                Result.success(true)
            } catch (e: Exception) {
                e.printStackTrace()
                Result.failure(e)
            }
        }
    }
}