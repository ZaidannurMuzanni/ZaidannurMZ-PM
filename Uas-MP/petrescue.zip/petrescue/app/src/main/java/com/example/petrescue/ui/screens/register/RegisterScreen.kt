package com.example.petrescue.ui.screens.register

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.petrescue.ui.components.*

@Composable
fun RegisterScreen(
    viewModel: RegisterViewModel = viewModel(),
    onRegisterSuccess: () -> Unit,
    onNavigateToLogin: () -> Unit
) {
    val context = LocalContext.current

    LaunchedEffect(viewModel.registerSuccess) {
        if (viewModel.registerSuccess) {
            onRegisterSuccess()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
            .padding(horizontal = 24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(40.dp))

        // Header
        AuthHeader(
            title = "Create Account",
            subtitle = "Join our community of volunteers and animal lovers."
        )

        // Tab Switcher
        AuthTabSwitcher(currentTab = "Register") { tab ->
            if (tab == "Login") onNavigateToLogin()
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Form Fields
        RescueTextField(
            value = viewModel.name,
            onValueChange = { viewModel.name = it },
            label = "Full Name",
            placeholder = "John Doe",
            icon = Icons.Default.Person
        )

        Spacer(modifier = Modifier.height(16.dp))

        RescueTextField(
            value = viewModel.email,
            onValueChange = { viewModel.email = it },
            label = "Email Address",
            placeholder = "your@email.com",
            icon = Icons.Default.Email,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )

        Spacer(modifier = Modifier.height(16.dp))

        RescueTextField(
            value = viewModel.phone,
            onValueChange = { viewModel.phone = it },
            label = "Phone Number",
            placeholder = "0812...",
            icon = Icons.Default.Phone,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )

        Spacer(modifier = Modifier.height(16.dp))

        RescueTextField(
            value = viewModel.password,
            onValueChange = { viewModel.password = it },
            label = "Password",
            placeholder = "Create a strong password",
            icon = Icons.Default.Lock,
            visualTransformation = PasswordVisualTransformation()
        )

        if (viewModel.errorMessage != null) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = viewModel.errorMessage!!,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Button
        RescueButton(
            text = "REGISTER NOW",
            onClick = { viewModel.onRegister() },
            isLoading = viewModel.isLoading
        )

        Spacer(modifier = Modifier.height(40.dp))
    }
}