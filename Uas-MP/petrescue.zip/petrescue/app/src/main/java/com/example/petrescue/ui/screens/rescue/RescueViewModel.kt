package com.example.petrescue.ui.screens.rescue

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.petrescue.data.remote.AppwriteClient
import kotlinx.coroutines.launch

class RescueViewModel : ViewModel() {

    // --- DATA REAL DARI DATABASE ---
    var animalTitle by mutableStateOf("Loading...")
    var locationName by mutableStateOf("Mengambil lokasi...")
    var severity by mutableStateOf("medium") // low, medium, high, critical

    // Status & Form (Data yang akan diupdate)
    var status by mutableStateOf("pending") // pending, in_progress, rescued
    var notes by mutableStateOf("")
    var estimatedTime by mutableStateOf("")

    var isLoading by mutableStateOf(false)
    var isSuccess by mutableStateOf(false)

    // 1. FUNGSI AMBIL DATA AWAL (PENTING AGAR TIDAK DUMMY)
    fun fetchReportDetails(reportId: String) {
        viewModelScope.launch {
            try {
                isLoading = true
                val response = AppwriteClient.databases.getDocument(
                    databaseId = "69638648002715e50d35", // ID Database Kamu
                    collectionId = "reports",             // ID Collection Reports
                    documentId = reportId
                )

                // Masukkan data DB ke State UI
                val data = response.data
                animalTitle = data["title"] as? String ?: "Tanpa Nama"
                locationName = data["description"] as? String ?: "Lokasi tidak tersedia"
                status = data["status"] as? String ?: "pending"
                severity = data["severity"] as? String ?: "medium"

                // Reset notes agar kosong saat dibuka
                notes = ""

            } catch (e: Exception) {
                e.printStackTrace()
                animalTitle = "Error memuat data"
            } finally {
                isLoading = false
            }
        }
    }

    // 2. FUNGSI UPDATE STATUS
    fun submitUpdate(reportId: String) {
        viewModelScope.launch {
            try {
                isLoading = true

                // Update ke Appwrite
                AppwriteClient.databases.updateDocument(
                    databaseId = "69638648002715e50d35",
                    collectionId = "reports",
                    documentId = reportId,
                    data = mapOf(
                        "status" to status
                        // Kita bisa tambah field 'notes' di database nanti jika perlu history
                    )
                )

                isSuccess = true
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }
}